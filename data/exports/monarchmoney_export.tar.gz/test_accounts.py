#!/usr/bin/env python3
import asyncio
import json
from monarchmoney import MonarchMoney

async def get_accounts():
    # Use existing session file
    mm = MonarchMoney(session_file=".mm/mm_session.pickle")
    
    try:
        # Try to get accounts with existing session
        print("Attempting to get accounts with existing session...")
        accounts = await mm.get_accounts()
        
        # Save to file
        with open("accounts.json", "w") as f:
            json.dump(accounts, f, indent=2)
        
        # Display summary
        print(f"\n✅ Successfully retrieved {len(accounts.get('accounts', []))} accounts")
        
        for account in accounts.get('accounts', []):
            print(f"\n📊 {account.get('displayName', 'Unknown')}")
            print(f"   Type: {account.get('type', {}).get('display', 'Unknown')}")
            print(f"   Balance: ${account.get('currentBalance', 0):,.2f}")
            print(f"   Institution: {account.get('institution', {}).get('name', 'Unknown')}")
            
        return accounts
        
    except Exception as e:
        print(f"\n❌ Session expired or invalid: {e}")
        print("\nTrying interactive login...")
        
        # If session is invalid, do interactive login
        await mm.interactive_login()
        
        # Try again after login
        accounts = await mm.get_accounts()
        
        # Save to file
        with open("accounts.json", "w") as f:
            json.dump(accounts, f, indent=2)
        
        print(f"\n✅ Successfully retrieved {len(accounts.get('accounts', []))} accounts after login")
        
        for account in accounts.get('accounts', []):
            print(f"\n📊 {account.get('displayName', 'Unknown')}")
            print(f"   Type: {account.get('type', {}).get('display', 'Unknown')}")
            print(f"   Balance: ${account.get('currentBalance', 0):,.2f}")
            print(f"   Institution: {account.get('institution', {}).get('name', 'Unknown')}")
            
        return accounts

if __name__ == "__main__":
    asyncio.run(get_accounts())