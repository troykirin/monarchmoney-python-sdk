# Network Traffic Flow Diagram - Cruise Ship to MonarchMoney via Tailscale

## Traffic Flow Visualization

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           CRUISE SHIP NETWORK                               │
│                                                                             │
│  ┌──────────────┐                                                          │
│  │  Your MacBook │                                                         │
│  │   on Cruise   │                                                         │
│  │ 100.100.148.63│ (Tailscale IP)                                         │
│  └──────┬───────┘                                                         │
│         │                                                                  │
│         │ 1️⃣ Encrypted Tailscale packets                                  │
│         │    (Cruise WiFi only sees this)                                 │
│         ▼                                                                  │
│  ┌──────────────┐                                                         │
│  │ Cruise WiFi  │ ❌ Can't see: MonarchMoney API calls                    │
│  │   Captive    │ ❌ Can't see: Your financial data                       │
│  │   Portal     │ ✅ Only sees: Encrypted packets to home                 │
│  └──────┬───────┘                                                         │
│         │                                                                  │
└─────────┼───────────────────────────────────────────────────────────────┘
          │
          │ 2️⃣ Tailscale WireGuard tunnel
          │    (End-to-end encrypted)
          ▼
    ╔═══════════╗
    ║ INTERNET  ║ ← Encrypted tunnel through public internet
    ╚═════╤═════╝
          │
          │ 3️⃣ Still encrypted via Tailscale
          ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        YOUR HOME IN WASHINGTON                              │
│                                                                             │
│  ┌──────────────┐                                                          │
│  │ Windows PC   │                                                          │
│  │  Exit Node   │ 🔓 Decrypts Tailscale traffic                           │
│  │ 100.73.235.28│ 🔄 Acts as proxy                                        │
│  │              │ 🔒 Re-encrypts with HTTPS                               │
│  └──────┬───────┘                                                          │
│         │                                                                  │
│         │ Your home IP: 50.46.47.106                                      │
│         │ ISP: Wholesail networks LLC                                     │
│         │ Location: Snohomish, WA                                         │
│         │                                                                  │
└─────────┼───────────────────────────────────────────────────────────────┘
          │
          │ 4️⃣ HTTPS request to MonarchMoney
          │    (Appears to come from your home)
          ▼
    ╔═══════════╗
    ║ INTERNET  ║
    ╚═════╤═════╝
          │
          │ 5️⃣ Standard HTTPS (port 443)
          ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         MONARCHMONEY SERVERS                                │
│                                                                             │
│  ┌──────────────┐                                                          │
│  │  MonarchMoney │                                                         │
│  │   API Server  │ 👀 Sees request from: Washington State                 │
│  │               │ ✅ Validates: Your API token                           │
│  │               │ 📊 Returns: Your financial data                        │
│  └──────┬───────┘                                                          │
│         │                                                                  │
│         │ api.monarchmoney.com                                            │
│         │ CloudFlare Protected (cf-ray: 96cc4b553f04ded8-SEA)            │
│         │                                                                  │
└─────────┼───────────────────────────────────────────────────────────────┘
          │
          │ 6️⃣ Response travels back the same path
          ▼

## Return Path (Response)

MonarchMoney → Your Home PC → Tailscale Tunnel → Your MacBook

```

## Security Layers

### 🔐 Layer 1: Tailscale VPN
- **Protocol**: WireGuard (modern, fast VPN protocol)
- **Encryption**: ChaCha20-Poly1305
- **Authentication**: Curve25519 keys
- **Network**: 100.x.x.x (CGNAT range)

### 🔐 Layer 2: HTTPS/TLS
- **Protocol**: TLS 1.3
- **Encryption**: AES-256-GCM
- **Port**: 443
- **Certificate**: MonarchMoney's SSL cert

## What Each Party Sees

### 👁️ Cruise Ship Network Sees:
```
Source: Your Mac's local IP
Destination: Your home IP (50.46.47.106)
Protocol: WireGuard/UDP
Content: [ENCRYPTED GIBBERISH]
```

### 👁️ Your ISP (at home) Sees:
```
Source: Your home IP
Destination: MonarchMoney (CloudFlare)
Protocol: HTTPS
Content: [ENCRYPTED - different encryption]
```

### 👁️ MonarchMoney Sees:
```
Source: Your home IP (50.46.47.106)
Location: Snohomish, Washington
Auth: Bearer Token 6396f61a42...
Request: GraphQL queries for accounts
```

## Benefits of This Setup

1. **🛡️ Privacy from Cruise WiFi**
   - They can't see you're accessing financial services
   - They can't perform man-in-the-middle attacks
   - They can't inject ads or tracking

2. **🏠 Home IP Reputation**
   - MonarchMoney sees your trusted home IP
   - Avoids triggering fraud alerts from unusual locations
   - Bypasses potential geo-restrictions

3. **🔒 Double Encryption**
   - Even if one layer was compromised, data still protected
   - Cruise network compromise = still safe (Tailscale)
   - Home network compromise = still safe (HTTPS)

4. **⚡ Performance**
   - Tailscale uses WireGuard (very efficient)
   - Direct peering when possible
   - Relay servers (SEA = Seattle) when needed

## Current Connection Stats
```
Exit Node: win-pc (Active ✅)
Relay: Seattle (sea)
Data Transferred: TX 23MB, RX 246MB
Latency: ~100-200ms (cruise → home → MonarchMoney)
```