# MonarchMoney Authentication Guide

## Getting Your API Token (Recommended)

The easiest way to use this tool is with an API token from your MonarchMoney account.

### Steps to Get Your Token:

1. **Login to MonarchMoney Web App**
   - Go to https://app.monarchmoney.com
   - Login with your credentials

2. **Open Developer Tools**
   - Press `F12` or right-click and select "Inspect"
   - Go to the **Network** tab

3. **Find Your Token**
   - Refresh the page or navigate to any section
   - Look for requests to `graphql` endpoint
   - Click on any GraphQL request
   - Go to the **Headers** tab
   - Find the `Authorization` header
   - Copy the value after `Token ` (e.g., `Token abc123...`)

4. **Set Environment Variable**
   ```bash
   export MONARCH_TOKEN='your_token_here'
   ```

   Or add to your `.bashrc` / `.zshrc`:
   ```bash
   echo "export MONARCH_TOKEN='your_token_here'" >> ~/.zshrc
   source ~/.zshrc
   ```

## Using the CLI Tools

### Quick Test - Get Accounts Only
```bash
python get_accounts_with_token.py
```

### Full Data Export - Get Everything
```bash
python monarch_cli.py
```

This will fetch:
- All accounts and balances
- Institutions
- Budgets
- Recent transactions (last 50)
- Transaction categories
- Current month cashflow
- Subscription details
- Calculate net worth

### Using Session File (Alternative)

If you prefer not to use a token, you can login interactively:

```python
import asyncio
from monarchmoney import MonarchMoney

async def login():
    mm = MonarchMoney()
    await mm.interactive_login()  # Will prompt for email/password
    
    # Test it worked
    accounts = await mm.get_accounts()
    print(f"Found {len(accounts['accounts'])} accounts")

asyncio.run(login())
```

The session will be saved to `.mm/mm_session.pickle` for future use.

## Troubleshooting

### Token Expired
- Tokens may expire after some time
- Simply get a new token from the web app following the steps above

### Connection Issues
- Check your internet connection
- Verify MonarchMoney service is up: https://status.monarchmoney.com/

### MFA Required
- If you have 2FA enabled, you'll need to use interactive login
- The tool will prompt for your 2FA code

## Security Notes

- **Never commit your token to git!** Add to `.gitignore`:
  ```
  .env
  .mm/
  monarch_data_*.json
  accounts*.json
  ```

- Store tokens in environment variables or secure password managers
- Tokens provide full access to your financial data - keep them secure!