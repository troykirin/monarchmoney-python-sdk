#!/usr/bin/env python3
"""
MonarchMoney CLI - Get all your financial data
"""

import asyncio
import json
import os
import sys
from datetime import datetime, timedelta
from monarchmoney import MonarchMoney

class MonarchCLI:
    def __init__(self):
        self.mm = None
        
    async def initialize(self):
        """Initialize MonarchMoney client with token or session"""
        # Try token first
        token = os.getenv('MONARCH_TOKEN')
        
        if token:
            print("🔑 Using API token from MONARCH_TOKEN environment variable")
            self.mm = MonarchMoney(token=token)
            return True
            
        # Try existing session
        session_file = ".mm/mm_session.pickle"
        if os.path.exists(session_file):
            print("📁 Found existing session file")
            self.mm = MonarchMoney(session_file=session_file)
            
            # Test if session is valid
            try:
                await self.mm.get_subscription_details()
                print("✅ Session is valid")
                return True
            except:
                print("⚠️  Session expired, need to login again")
        
        # Interactive login
        print("\n🔐 Please login to MonarchMoney")
        self.mm = MonarchMoney()
        await self.mm.interactive_login()
        return True
    
    async def get_all_data(self):
        """Fetch all available financial data"""
        if not self.mm:
            await self.initialize()
        
        data = {}
        
        # 1. Get Accounts
        print("\n📊 Fetching accounts...")
        try:
            accounts = await self.mm.get_accounts()
            data['accounts'] = accounts
            print(f"   ✓ Found {len(accounts.get('accounts', []))} accounts")
            
            # Display account summary
            for acc in accounts.get('accounts', []):
                print(f"     • {acc.get('displayName')}: ${acc.get('currentBalance', 0):,.2f}")
        except Exception as e:
            print(f"   ✗ Error: {e}")
        
        # 2. Get Institutions
        print("\n🏦 Fetching institutions...")
        try:
            institutions = await self.mm.get_institutions()
            data['institutions'] = institutions
            print(f"   ✓ Found {len(institutions.get('institutions', []))} institutions")
        except Exception as e:
            print(f"   ✗ Error: {e}")
        
        # 3. Get Budgets
        print("\n💰 Fetching budgets...")
        try:
            budgets = await self.mm.get_budgets()
            data['budgets'] = budgets
            
            # Show current month budget if available
            if budgets and 'budgetData' in budgets:
                current_month = datetime.now().strftime('%Y-%m')
                for month_data in budgets['budgetData']:
                    if month_data.get('month', '').startswith(current_month):
                        print(f"   ✓ Current month budget:")
                        print(f"     • Planned Income: ${month_data.get('plannedIncome', 0):,.2f}")
                        print(f"     • Planned Expenses: ${month_data.get('plannedExpenses', 0):,.2f}")
                        break
        except Exception as e:
            print(f"   ✗ Error: {e}")
        
        # 4. Get Recent Transactions
        print("\n💳 Fetching recent transactions...")
        try:
            transactions = await self.mm.get_transactions(limit=50)
            data['recent_transactions'] = transactions
            print(f"   ✓ Found {len(transactions.get('allTransactions', {}).get('results', []))} recent transactions")
        except Exception as e:
            print(f"   ✗ Error: {e}")
        
        # 5. Get Transaction Categories
        print("\n🏷️  Fetching transaction categories...")
        try:
            categories = await self.mm.get_transaction_categories()
            data['categories'] = categories
            print(f"   ✓ Found {len(categories.get('categories', []))} categories")
        except Exception as e:
            print(f"   ✗ Error: {e}")
        
        # 6. Get Cashflow for current month
        print("\n📈 Fetching cashflow...")
        try:
            start_date = datetime.now().replace(day=1).strftime('%Y-%m-%d')
            end_date = datetime.now().strftime('%Y-%m-%d')
            
            cashflow = await self.mm.get_cashflow(
                start_date=start_date,
                end_date=end_date
            )
            data['cashflow'] = cashflow
            
            # Show summary if available
            if cashflow and 'summary' in cashflow:
                for period in cashflow['summary']:
                    summary = period.get('summary', {})
                    print(f"   ✓ Current month cashflow:")
                    print(f"     • Income: ${summary.get('sumIncome', 0):,.2f}")
                    print(f"     • Expenses: ${summary.get('sumExpense', 0):,.2f}")
                    print(f"     • Savings: ${summary.get('savings', 0):,.2f}")
                    if summary.get('savingsRate'):
                        print(f"     • Savings Rate: {summary['savingsRate']:.1%}")
                    break
        except Exception as e:
            print(f"   ✗ Error: {e}")
        
        # 7. Get Subscription Details
        print("\n🔔 Fetching subscription details...")
        try:
            subscription = await self.mm.get_subscription_details()
            data['subscription'] = subscription
            print(f"   ✓ Subscription status retrieved")
        except Exception as e:
            print(f"   ✗ Error: {e}")
        
        # Save all data
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"monarch_data_{timestamp}.json"
        
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        
        print(f"\n✅ All data saved to {filename}")
        
        # Calculate and show net worth
        if 'accounts' in data:
            total_assets = sum(
                acc.get('currentBalance', 0) 
                for acc in data['accounts'].get('accounts', [])
                if acc.get('isAsset', True)
            )
            total_liabilities = sum(
                abs(acc.get('currentBalance', 0))
                for acc in data['accounts'].get('accounts', [])
                if not acc.get('isAsset', True)
            )
            
            print("\n" + "="*50)
            print("📊 FINANCIAL SUMMARY")
            print("="*50)
            print(f"💰 Total Assets:      ${total_assets:,.2f}")
            print(f"💳 Total Liabilities: ${total_liabilities:,.2f}")
            print(f"📈 Net Worth:         ${(total_assets - total_liabilities):,.2f}")
            print("="*50)
        
        return data

async def main():
    cli = MonarchCLI()
    
    if len(sys.argv) > 1 and sys.argv[1] == '--help':
        print("""
MonarchMoney CLI - Get all your financial data

Usage:
  python monarch_cli.py              # Fetch all data
  python monarch_cli.py --help       # Show this help

Authentication (in order of preference):
  1. Set MONARCH_TOKEN environment variable with your API token
  2. Use existing session in .mm/mm_session.pickle
  3. Interactive login (will be prompted)

To get your API token:
  1. Log into https://app.monarchmoney.com
  2. Open Developer Tools (F12)
  3. Go to Network tab and find a GraphQL request
  4. Copy the token from Authorization header
  5. export MONARCH_TOKEN='your_token_here'
        """)
        return
    
    try:
        await cli.get_all_data()
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted by user")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())