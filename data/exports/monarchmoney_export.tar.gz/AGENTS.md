# MonarchMoney Python SDK - Agent Guidelines

## Build & Test Commands
```bash
# Install dependencies
pip install -r requirements.txt

# Run all tests
python -m unittest tests/test_monarchmoney.py

# Run single test
python -m unittest tests.test_monarchmoney.TestMonarchMoney.test_get_accounts

# Lint with black (install: pip install black)
black monarchmoney/ tests/

# Type check with pyre (optional)
pyre check
```

## Code Style Guidelines
- **Formatter**: Black (line length default 88)
- **Imports**: Group as stdlib, third-party, local; alphabetical within groups
- **Type Hints**: Use typing module (Dict, List, Optional, Union, Any)
- **Naming**: snake_case for functions/variables, PascalCase for classes
- **Constants**: UPPER_SNAKE_CASE, defined at module level
- **Exceptions**: Custom exceptions inherit from base Exception class
- **Async**: Use async/await for all API calls, prefix async methods with no special naming
- **Error Handling**: Raise custom exceptions (RequireMFAException, LoginFailedException, RequestFailedException)
- **File Structure**: Main logic in monarchmoney/monarchmoney.py, tests mirror structure in tests/